angular.module('contactUs', ['ngResource'])
    .controller('contactUsCtrl', ['$scope', '$stateParams',
function ($scope, $stateParams) {


}]);
